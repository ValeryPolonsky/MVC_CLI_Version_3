package controller;

import algorithms.search.Solution;

public class MyController extends CommonController {

	@Override
	public void stop() {
		view.displayShuttingDown();
		model.stop();
		view.displayShutDown();
	}

	@Override
	public void displayError(String error) {
		view.displayError(error);
	}

	@Override
	public void displayFilesList(String[] list) {	
		view.displayFiles(list);
	}

	@Override
	public void display3dMazeReady(String name) {
		view.displayMazeReady(name);
	}

	@Override
	public void display3dMaze(byte[] mazeData) {
		view.display3DMaze(mazeData);
	}

	@Override
	public void displayCrossSection(int[][] crossSection) {
		view.displayCrossSection(crossSection);;
	}

	@Override
	public void display3dMazeSaved(String name) {
		view.display3DMazeSaved(name);
	}

	@Override
	public void display3dMazeLoaded(String name) {
		view.display3DMazeLoaded(name);
	}

	@Override
	public void displayMazeSize(int size) {
		view.displayMazeSize(size);
	}

	@Override
	public void displayFileSize(int length) {
		view.displayFileSize(length);
	}

	@Override
	public void displaySolutionReady(String name) {
		view.displaySolutionReady(name);
	}

	@Override
	public void displaySolution(Solution solution) {
		view.displaySolution(solution);
	}

	@Override
	protected void initCommands() {
		commands.put("dir",new Command(){
		@Override
		public void doCommand(String[]data)
		{
			if(data.length!=1){
				view.displayError("Wrong arguments: dir <path>");
				return;
			}
			model.calculateFileList(data[0]);
		}
		});
		
		commands.put("generate3dMaze",new Command(){
		@Override
		public void doCommand(String[]data)
		{
			
			if(data.length!=4){
				view.displayError("Wrong arguments: generate3dMaze <maze name> <length> <height> <width>");
				return;
			}
			String mazeName=data[0];
			int length=Integer.parseInt(data[1]);
			int height=Integer.parseInt(data[2]);
			int width=Integer.parseInt(data[3]);
			model.generate3DMaze(mazeName, length, height, width);
		}
		});
		
		commands.put("display",new Command(){
		@Override
		public void doCommand(String[]data)
		{
			if(data.length!=1){
				view.displayError("Wrong arguments: display <maze name>");
				return;
			}
			model.get3DMaze(data[0]);
		}
		});
		
		commands.put("displayCrossSection",new Command(){
		@Override
		public void doCommand(String[]data)
		{
			if(data.length!=3){
				view.displayError("Wrong arguments: displayCrossSection <maze name> <axis> <index>");
				return;
			}
			model.getCrossSection(data[0], data[1], Integer.parseInt(data[2]));
		}
		});
		
		commands.put("saveMaze",new Command(){
		@Override
		public void doCommand(String[]data)
		{
			if(data.length!=2){
				view.displayError("Wrong arguments: saveMaze <maze name> <file name>");
				return;
			}
			model.saveMaze(data[0], data[1]);
		}
		});
		
		commands.put("loadMaze",new Command(){
		@Override
		public void doCommand(String[]data)
		{
			if(data.length!=2){
				view.displayError("Wrong arguments: loadMaze <file name> <maze name>");
				return;
			}
			model.loadMaze(data[0], data[1]);
		}
		});
		
		commands.put("mazeSize",new Command(){
		@Override
		public void doCommand(String[]data)
		{
			if(data.length!=1){
				view.displayError("Wrong arguments: mazeSize <maze name>");
				return;
			}
			model.calculateMazeSize(data[0]);
		}
		});
		
		commands.put("fileSize",new Command(){
		@Override
		public void doCommand(String[]data)
		{
			if(data.length!=1){
				view.displayError("Wrong arguments: fileMaze <file name>");
				return;
			}
			model.calculateFileSize(data[0]);
		}
		});
		
		commands.put("solve",new Command(){
		@Override
		public void doCommand(String[]data)
		{
			if(data.length!=2){
				view.displayError("Wrong arguments: solve <maze name> <algorithm>");
				return;
			}
			model.solveMaze(data[0], data[1]);
		}
		});
		
		commands.put("displaySolution",new Command(){
		@Override
		public void doCommand(String[]data)
		{
			if(data.length!=1){
				view.displayError("Wrong arguments: displaySolution <maze name>");
				return;
			}
			model.getSolution(data[0]);
		}
		});
	}
}
